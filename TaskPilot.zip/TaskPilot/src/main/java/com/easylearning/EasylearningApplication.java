package com.easylearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasylearningApplication {
    public static void main(String[] args) {
        SpringApplication.run(EasylearningApplication.class, args);
    }
}
